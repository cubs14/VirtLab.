import '../models/experiment.dart';

/// Contenido migrado desde F_Intro.bky / F_Preguntas.bky. Materiales
/// y pasos como checklist, preguntas de opción múltiple.
const List<Experiment> fisicaExperiments = [
  Experiment(
    id: 'velosidad',
    title: 'Velocidad de un objeto',
    materials: ['Una cinta métrica', 'Una pelota', 'Un cronómetro'],
    steps: [
      'Estira la cinta métrica a 10 metros',
      'Vuelve al inicio y coloca la pelota',
      'Dale un pequeño impulso',
      'Mide el tiempo que tarda en terminar',
    ],
    questions: [
      Question(
        text: '¿Qué necesitas para calcular la velocidad de la pelota?',
        options: ['Solo el peso de la pelota', 'La distancia recorrida y el tiempo que tardó', 'Solo el color de la pelota', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿La velocidad fue constante?',
        options: ['Sí, siempre es la misma', 'Aumenta sola sin motivo', 'No, disminuye por la fricción y el aire', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué factores afectan la velocidad?',
        options: ['El color del objeto', 'La hora del día', 'La fuerza del impulso, la fricción y el peso del objeto', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: 'Si una pelota recorre 10 metros en 2 segundos, ¿cuál es su velocidad?',
        options: ['20 m/s', '5 m/s', '2 m/s', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
    ],
  ),
  Experiment(
    id: 'fuerza',
    title: 'Fuerza y movimiento',
    materials: ['Libro', 'Una mesa o base alta'],
    steps: [
      'Coloca el libro sobre la base',
      'Empuja suavemente el libro',
      'Empuja un poco más fuerte',
      'Observa sus distintos movimientos',
    ],
    questions: [
      Question(
        text: '¿Qué ocurre al aplicar más fuerza?',
        options: ['El objeto no se mueve', 'El objeto se vuelve más pesado', 'El objeto se mueve más rápido o más lejos', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Cómo cambia el movimiento del objeto?',
        options: ['Se detiene por completo', 'Aumenta su velocidad o aceleración', 'Cambia de color', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Qué relación hay entre fuerza y movimiento?',
        options: ['No tienen relación', 'La fuerza siempre detiene el movimiento', 'A mayor fuerza aplicada, mayor cambio en el movimiento', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: 'Si aumentas la fuerza aplicada a un objeto, ¿qué ocurre con su aceleración?',
        options: ['Disminuye', 'Se mantiene igual', 'También aumenta', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'tiempo',
    title: 'Medición del tiempo',
    materials: ['Cronómetro', 'Una pelota'],
    steps: [
      'Lanza la pelota hacia arriba',
      'Mide el tiempo que dura en caer',
      'Repite 2 o más veces',
      'Compara los resultados',
    ],
    questions: [
      Question(
        text: '¿Cuánto tiempo tarda en caer la pelota?',
        options: ['Siempre el mismo tiempo sin importar la altura', 'Depende de la altura desde donde se lanza', 'Nunca cae', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿El tiempo fue siempre igual?',
        options: ['Sí, siempre exactamente igual', 'El tiempo no se puede medir', 'No, puede variar un poco entre intentos', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué factores pueden afectar el tiempo?',
        options: ['El color de la pelota', 'El nombre de quien lanza', 'La altura, la resistencia del aire y la precisión al medir', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: 'Si un objeto tarda más tiempo en caer, ¿qué pudo haber cambiado?',
        options: ['Se lanzó desde más alto o hubo más resistencia del aire', 'El objeto se volvió invisible', 'La gravedad desapareció', 'No estoy seguro/a'],
        correctIndex: 0,
      ),
    ],
  ),
  Experiment(
    id: 'inercia',
    title: 'Inercia de los objetos',
    materials: ['Una tarjeta', 'Una moneda de cualquier tamaño', 'Un vaso'],
    steps: [
      'Pon la tarjeta sobre el vaso',
      'Pon la moneda sobre la tarjeta',
      'Golpea rápidamente la tarjeta hacia cualquier dirección',
      'Observa lo que pasa con la moneda',
    ],
    questions: [
      Question(
        text: '¿Qué ocurrió con la moneda al mover la tarjeta?',
        options: ['Salió volando lejos', 'Se quedó pegada a la tarjeta', 'Cayó dentro del vaso en su lugar', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Por qué crees que pasó eso con la moneda?',
        options: ['Por el peso de la tarjeta', 'Por el color de la moneda', 'Por inercia, la moneda tiende a quedarse en reposo', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Por qué la moneda no se mueve junto con la tarjeta al ser golpeada?',
        options: ['Porque la moneda está pegada al vaso', 'Porque la tarjeta repele a la moneda', 'Porque el golpe es tan rápido que no alcanza a arrastrarla', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué pasaría con la moneda si la tarjeta se moviera lentamente en lugar de rápido?',
        options: ['La moneda desaparecería', 'La moneda se movería junto con la tarjeta', 'No cambiaría nada', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
    ],
  ),
];
