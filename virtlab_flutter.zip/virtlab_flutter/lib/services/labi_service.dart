import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Un turno de la conversación con Labi.
class ChatTurn {
  final bool fromUser;
  final String text;
  const ChatTurn({required this.fromUser, required this.text});
}

/// Un proveedor de IA que LABI puede usar. Todos hablan el mismo
/// formato de petición estilo OpenAI ("chat/completions"), así que
/// se pueden probar en cadena con el mismo código.
class _Provider {
  final String name;
  final String apiKey;
  final String endpoint;
  final String model;
  const _Provider({
    required this.name,
    required this.apiKey,
    required this.endpoint,
    required this.model,
  });
}

/// LABI — el asistente inteligente oficial de VirtLab.
///
/// Motor de IA con respaldo en cadena: intenta primero con Groq
/// (rápido); si Groq falla o no responde, reintenta con Gemini; si
/// también falla, reintenta con Cerebras. Así LABI casi nunca se
/// queda "callado" por un problema de un solo proveedor.
///
/// ⚠️ Ninguna API key vive en este archivo ni en ningún otro archivo
/// fuente. Se reciben únicamente al momento de compilar:
///
///   flutter build apk --release \
///     --dart-define=GROQ_API_KEY=tu_key \
///     --dart-define=GEMINI_API_KEY=tu_key \
///     --dart-define=CEREBRAS_API_KEY=tu_key
///
/// En GitHub Actions esas keys se guardan como Secrets del repositorio
/// (Settings → Secrets and variables → Actions) y el workflow se las
/// pasa al compilador con --dart-define.
class LabiService {
  static const String _groqKey = String.fromEnvironment('GROQ_API_KEY');
  static const String _geminiKey = String.fromEnvironment('GEMINI_API_KEY');
  static const String _cerebrasKey = String.fromEnvironment('CEREBRAS_API_KEY');

  /// Orden de respaldo: Groq → Gemini → Cerebras. Un proveedor sin
  /// key configurada se salta automáticamente.
  static List<_Provider> get _providers => [
        if (_groqKey.isNotEmpty)
          _Provider(
            name: 'Groq',
            apiKey: _groqKey,
            endpoint: 'https://api.groq.com/openai/v1/chat/completions',
            // GPT-OSS 120B es el modelo insignia actual de Groq: más
            // rápido, más barato y más reciente que Llama 3.3 70B
            // (que Groq ya está retirando).
            model: 'openai/gpt-oss-120b',
          ),
        if (_geminiKey.isNotEmpty)
          _Provider(
            name: 'Gemini',
            apiKey: _geminiKey,
            // Endpoint de Gemini compatible con el formato OpenAI.
            endpoint:
                'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
            // Gemini 3.7 Flash: el modelo Flash más reciente de
            // Google, agosto 2026.
            model: 'gemini-3.7-flash',
          ),
        if (_cerebrasKey.isNotEmpty)
          _Provider(
            name: 'Cerebras',
            apiKey: _cerebrasKey,
            endpoint: 'https://api.cerebras.ai/v1/chat/completions',
            // GPT-OSS 120B es, a la fecha, el único modelo de
            // producción (no preview) vigente en Cerebras.
            model: 'gpt-oss-120b',
          ),
      ];

  /// Cuántos turnos recientes de la conversación se envían — se
  /// limita para no gastar de más en conversaciones largas.
  static const int _maxHistoryTurns = 12;

  static const String _systemPrompt = '''
Eres LABI, el asistente oficial de VirtLab.

Tu misión es ayudar a los estudiantes a descubrir, experimentar y comprender la ciencia de forma sencilla, divertida y segura.

Explica los conceptos utilizando ejemplos fáciles.

Motiva al usuario a seguir aprendiendo.

Nunca respondas de forma ofensiva.

Nunca inventes datos científicos.

Si no conoces una respuesta indícalo con honestidad.

Siempre mantén un tono amigable y educativo.''';

  /// Mensaje inicial de Labi al terminar un experimento.
  Future<String> getInitialFeedback({
    required String experimentTitle,
    required int correctCount,
    required int totalQuestions,
  }) {
    final prompt =
        'Acabo de completar el experimento "$experimentTitle" en VirtLab '
        'y acerté $correctCount de $totalQuestions preguntas. Dame una '
        'felicitación breve y motivadora, y si fallé algo anímame a '
        'repasarlo, en un tono cercano y en español.';
    return sendMessage([ChatTurn(fromUser: true, text: prompt)]);
  }

  /// Continúa la conversación: manda el historial reciente para que
  /// Labi tenga contexto, igual que cualquier chat de IA.
  ///
  /// Prueba cada proveedor de _providers en orden (Groq → Gemini →
  /// Cerebras). Si uno falla por un problema temporal (timeout, error
  /// de servidor, límite de peticiones agotado, modelo no disponible),
  /// pasa automáticamente al siguiente antes de rendirse.
  Future<String> sendMessage(List<ChatTurn> history) async {
    final providers = _providers;
    if (providers.isEmpty) {
      return 'Todavía no tengo configurada ninguna clave de acceso a IA '
          '(Groq, Gemini o Cerebras). Pídele al desarrollador que agregue '
          'al menos una en la configuración de compilación. 🔧';
    }

    final recent = history.length > _maxHistoryTurns
        ? history.sublist(history.length - _maxHistoryTurns)
        : history;

    final messages = [
      {'role': 'system', 'content': _systemPrompt},
      ...recent.map((t) => {'role': t.fromUser ? 'user' : 'assistant', 'content': t.text}),
    ];

    for (var i = 0; i < providers.length; i++) {
      final provider = providers[i];
      final isLastProvider = i == providers.length - 1;
      try {
        final response = await http
            .post(
              Uri.parse(provider.endpoint),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ${provider.apiKey}',
              },
              body: jsonEncode({
                'model': provider.model,
                'messages': messages,
                'temperature': 0.7,
              }),
            )
            .timeout(const Duration(seconds: 25));

        if (response.statusCode == 200) {
          final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
          final choices = data['choices'] as List<dynamic>?;
          if (choices == null || choices.isEmpty) {
            if (!isLastProvider) continue;
            return _fallbackEmpty();
          }
          final text = (choices.first['message']?['content'] as String?)?.trim();
          if (text == null || text.isEmpty) {
            if (!isLastProvider) continue;
            return _fallbackEmpty();
          }
          return text;
        }

        // Clave inválida en ese proveedor: se intenta con el siguiente
        // antes de rendirse.
        if (response.statusCode == 401 || response.statusCode == 403) {
          if (!isLastProvider) continue;
          return 'No pude conectarme con ${provider.name} — puede que su '
              'clave de configuración no sea válida. Avísale al '
              'desarrollador. 🔑';
        }

        // Límite de peticiones agotado o modelo no disponible: se
        // intenta con el siguiente proveedor de la cadena.
        if ((response.statusCode == 429 || response.statusCode == 404) &&
            !isLastProvider) {
          continue;
        }
        if (response.statusCode == 429) {
          return 'Estoy recibiendo demasiadas preguntas de golpe. Espera '
              'un momento e inténtalo de nuevo. ⏳';
        }

        if (!isLastProvider) continue;
        return '${_fallbackConnection()}\n\n(detalle técnico temporal: '
            '${provider.name} HTTP ${response.statusCode} — '
            '${response.body.length > 200 ? response.body.substring(0, 200) : response.body})';
      } on TimeoutException {
        if (!isLastProvider) continue;
        return _fallbackConnection();
      } catch (e) {
        if (!isLastProvider) continue;
        return '${_fallbackConnection()}\n\n(detalle técnico temporal: $e)';
      }
    }
    return _fallbackConnection();
  }

  String _fallbackConnection() =>
      'LABI necesita conexión a internet para responder. Verifica tu '
      'conexión e inténtalo de nuevo. 📶';

  String _fallbackEmpty() =>
      'Hmm, no logré pensar en una buena respuesta para eso. ¿Puedes '
      'reformular tu pregunta? 🤔';
}
