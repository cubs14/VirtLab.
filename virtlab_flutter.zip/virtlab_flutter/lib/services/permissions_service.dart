import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:permission_handler/permission_handler.dart';

/// Centraliza los permisos nativos que VirtLab necesita:
/// - Cámara y galería: para poder cambiar la foto de perfil.
///
/// El flujo pedido es: al abrir la app se piden (ver
/// PermissionsGateScreen); si el usuario los niega, no pasa nada
/// grave todavía -puede seguir usando VirtLab-, pero en el momento en
/// que intente cambiar su foto de perfil (ProfileScreen), se le
/// vuelve a pedir el permiso cada vez que toque la foto, y no se le
/// deja avanzar hasta que lo conceda.
///
/// En la versión web (deploy-web.yml) no existe el concepto de
/// permiso de cámara/galería tal como lo maneja permission_handler en
/// Android (el selector de archivos del navegador no requiere
/// permiso). Por eso, en web esta clase se comporta como si todo
/// estuviera siempre concedido, para no romper ni bloquear esa
/// versión.
class PermissionsService {
  Future<bool> get cameraGranted async {
    if (kIsWeb) return true;
    return (await Permission.camera.status).isGranted;
  }

  Future<bool> get photosGranted async {
    if (kIsWeb) return true;
    return (await Permission.photos.status).isGranted;
  }

  /// Cámara Y galería concedidas a la vez (lo que necesita el
  /// selector de foto de perfil, que ofrece ambas opciones).
  Future<bool> get mediaGranted async =>
      (await cameraGranted) && (await photosGranted);

  Future<bool> get allEssentialGranted async => mediaGranted;

  /// Pide cámara y galería juntas. Devuelve true solo si AMBAS
  /// quedaron concedidas.
  Future<bool> requestMedia() async {
    if (kIsWeb) return true;
    final statuses = await [Permission.camera, Permission.photos].request();
    return statuses.values.every((status) => status.isGranted);
  }

  /// true si el usuario marcó "no volver a preguntar" en cámara o
  /// galería: en ese caso el sistema operativo ya no vuelve a
  /// mostrar el diálogo nativo, así que la única salida es guiarlo a
  /// Ajustes.
  Future<bool> get mediaPermanentlyDenied async {
    if (kIsWeb) return false;
    final camera = await Permission.camera.status;
    final photos = await Permission.photos.status;
    return camera.isPermanentlyDenied || photos.isPermanentlyDenied;
  }

  Future<void> openSettings() async {
    if (kIsWeb) return;
    await openAppSettings();
  }
}
