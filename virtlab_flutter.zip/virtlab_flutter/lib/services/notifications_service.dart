import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// "Notificaciones de ánimo": recordatorios locales que invitan al
/// usuario a volver a VirtLab si pasa varios días sin abrir la app
/// (justo lo que necesita, entre otras cosas, para no perderse el
/// logro secreto de racha de 3 semanas... o para no desbloquear el
/// otro, jeje).
///
/// No dependen de ningún backend: se reprograman por completo cada
/// vez que la app arranca (ver AppState.bootstrap), tomando "ahora"
/// como el último momento de actividad. Así, si el usuario nunca
/// vuelve a abrir VirtLab, estos avisos le siguen llegando al celular
/// aunque la app esté completamente cerrada.
///
/// flutter_local_notifications no tiene implementación para web, así
/// que en esa plataforma (deploy-web.yml) esta clase directamente no
/// hace nada, para no romper esa versión de la app.
class NotificationsService {
  static final NotificationsService _instance = NotificationsService._internal();
  factory NotificationsService() => _instance;
  NotificationsService._internal();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  // IDs fijos para poder cancelar y reprogramar siempre el mismo lote.
  static const _baseId = 9000;

  static const _messages = <_ComebackMessage>[
    _ComebackMessage(
      daysAfter: 2,
      title: '🧪 Tus experimentos te extrañan',
      body: '¿Volvemos al laboratorio? Te esperan nuevos descubrimientos en VirtLab.',
    ),
    _ComebackMessage(
      daysAfter: 5,
      title: '🔬 Labi pregunta por ti',
      body: 'Hace días que no vienes por VirtLab. ¡No dejes enfriar los experimentos!',
    ),
    _ComebackMessage(
      daysAfter: 9,
      title: '🏆 Tu racha te espera',
      body: 'Vuelve a VirtLab y sigue desbloqueando logros antes de que se te olvide todo.',
    ),
    _ComebackMessage(
      daysAfter: 14,
      title: '🎯 ¡Dos semanas ya!',
      body: 'VirtLab no es lo mismo sin ti. Un experimento rápido y quedamos a mano 😉',
    ),
    _ComebackMessage(
      daysAfter: 20,
      title: '⏳ Un día más y...',
      body: 'Mejor no lo averigües. Abre VirtLab y vuelve a la acción.',
    ),
  ];

  Future<void> init() async {
    if (kIsWeb || _initialized) return;
    tzdata.initializeTimeZones();
    // No hay forma de detectar la zona horaria real del dispositivo
    // sin un paquete adicional (p. ej. flutter_timezone); se usa UTC
    // como referencia interna. Como estos avisos se calculan en días
    // completos (no en una hora exacta del día), la diferencia de
    // huso horario no cambia qué día llegan.
    tz.setLocalLocation(tz.UTC);

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);
    _initialized = true;
  }

  Future<void> cancelComebackReminders() async {
    if (kIsWeb) return;
    await init();
    for (var i = 0; i < _messages.length; i++) {
      await _plugin.cancel(_baseId + i);
    }
  }

  /// Cancela cualquier recordatorio pendiente y programa uno nuevo
  /// por cada mensaje de [_messages], contando los días a partir de
  /// [from] (por defecto, ahora mismo).
  Future<void> scheduleComebackReminders({DateTime? from}) async {
    if (kIsWeb) return;
    await init();
    await cancelComebackReminders();

    final base = from ?? DateTime.now();
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'virtlab_animo',
        'Recordatorios de VirtLab',
        channelDescription:
            'Notificaciones de ánimo para volver a experimentar en VirtLab.',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
      ),
    );

    for (var i = 0; i < _messages.length; i++) {
      final msg = _messages[i];
      final when = tz.TZDateTime.from(base.add(Duration(days: msg.daysAfter)), tz.local);
      await _plugin.zonedSchedule(
        _baseId + i,
        msg.title,
        msg.body,
        when,
        details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      );
    }
  }
}

class _ComebackMessage {
  final int daysAfter;
  final String title;
  final String body;
  const _ComebackMessage({
    required this.daysAfter,
    required this.title,
    required this.body,
  });
}
