import 'package:flutter/material.dart';
import '../models/achievement.dart';
import '../models/user_profile.dart';
import '../services/achievements_service.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/notifications_service.dart';
import '../services/permissions_service.dart';
import '../services/preferences_service.dart';
import '../theme/colorblind.dart';

/// Estado central de VirtLab: sesión, perfil, personalización y
/// logros. Se expone con Provider para que cualquier pantalla
/// reaccione a cambios (por ejemplo, si cambia el color de fondo en
/// "Personaliza tu experiencia", el Menú se repinta al instante).
class AppState extends ChangeNotifier {
  final AuthService authService = AuthService();
  final FirestoreService firestoreService = FirestoreService();
  final PreferencesService prefsService = PreferencesService();
  final AchievementsService achievementsService = AchievementsService();
  final NotificationsService notificationsService = NotificationsService();
  final PermissionsService permissionsService = PermissionsService();

  bool loading = true;
  bool loggedIn = false;
  UserProfile? profile;

  /// Racha actual de días seguidos abriendo VirtLab (ver
  /// _updateStreakAndAchievements). Se muestra en el Perfil y también
  /// desbloquea "logro_racha_semana" al llegar a 7.
  int currentStreak = 0;

  // Personalización
  Color backgroundColor = const Color(0xFF9BFAB0);
  Color buttonColor = const Color(0xFF2A8C4A);
  Color textColor = const Color(0xFF15321F);
  double textScale = 1.0;
  ColorBlindMode colorBlindMode = ColorBlindMode.none;

  List<Achievement> achievements = [];
  Achievement? justUnlocked;

  Future<void> bootstrap() async {
    loading = true;
    notifyListeners();

    loggedIn = await prefsService.isLoggedIn();
    final uid = await prefsService.getUid();

    final localPrefs = await prefsService.loadPersonalization();
    _applyPersonalizationMap(localPrefs);

    if (loggedIn && uid != null) {
      profile = await firestoreService.getUserProfile(uid);
      final remotePrefs = await firestoreService.getPersonalization(uid);
      if (remotePrefs != null) _applyPersonalizationMap(remotePrefs);
    }

    achievements = await achievementsService.loadAll(uid);

    // La racha y el logro secreto de desconexión dependen de los
    // logros ya cargados (para poder desbloquearlos), así que se
    // calculan justo después.
    await _updateStreakAndAchievements();
    await _refreshComebackReminders();

    loading = false;
    notifyListeners();
  }

  /// Compara la fecha de hoy contra la última vez que se abrió la
  /// app (guardada en SharedPreferences) para:
  /// - Sumar 1 a la racha si entró un día después del anterior.
  /// - Reiniciar la racha si se saltó uno o más días.
  /// - Desbloquear "logro_racha_semana" al llegar a 7 días seguidos.
  /// - Desbloquear el logro secreto "logro_desconectado_secreto" si
  ///   pasaron 3 semanas (21 días) o más sin abrir VirtLab.
  Future<void> _updateStreakAndAchievements() async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final lastActive = await prefsService.getLastActiveDate();
    int streak = await prefsService.getCurrentStreak();

    if (lastActive == null) {
      streak = 1;
    } else {
      final lastDay = DateTime(lastActive.year, lastActive.month, lastActive.day);
      final gapDays = today.difference(lastDay).inDays;
      if (gapDays == 0) {
        // Ya había entrado hoy: la racha no cambia.
      } else if (gapDays == 1) {
        streak += 1;
      } else {
        // Racha rota. Si estuvo desconectado 3 semanas o más, se
        // desbloquea el logro secreto ANTES de reiniciar la racha.
        if (gapDays >= 21) {
          await unlockAchievement('logro_desconectado_secreto');
        }
        streak = 1;
      }
    }

    await prefsService.setLastActiveDate(today);
    await prefsService.setCurrentStreak(streak);
    currentStreak = streak;

    if (streak >= 7) {
      await unlockAchievement('logro_racha_semana');
    }
  }

  /// Reprograma las notificaciones locales de ánimo cada vez que la
  /// app arranca: solo si el usuario concedió el permiso de
  /// notificaciones Y no las desactivó desde Personalizar.
  Future<void> _refreshComebackReminders() async {
    final hasPermission = await permissionsService.notificationsGranted;
    final userWantsThem = await prefsService.notificationsEnabled();
    if (hasPermission && userWantsThem) {
      await notificationsService.scheduleComebackReminders();
    } else {
      await notificationsService.cancelComebackReminders();
    }
  }

  void _applyPersonalizationMap(Map<String, dynamic> map) {
    if (map['backgroundColor'] != null) {
      backgroundColor = Color(map['backgroundColor'] as int);
    }
    if (map['buttonColor'] != null) {
      buttonColor = Color(map['buttonColor'] as int);
    }
    if (map['textColor'] != null) {
      textColor = Color(map['textColor'] as int);
    }
    textScale = (map['textScale'] as num?)?.toDouble() ?? textScale;
    colorBlindMode =
        ColorBlindModeX.fromStorage(map['colorBlindMode'] as String? ?? 'none');
  }

  Future<void> savePersonalization() async {
    await prefsService.savePersonalization(
      backgroundColor: backgroundColor.value,
      buttonColor: buttonColor.value,
      textColor: textColor.value,
      textScale: textScale,
      colorBlindMode: colorBlindMode.name,
    );
    final uid = profile?.uid;
    if (uid != null) {
      await firestoreService.savePersonalization(uid, {
        'backgroundColor': backgroundColor.value,
        'buttonColor': buttonColor.value,
        'textColor': textColor.value,
        'textScale': textScale,
        'colorBlindMode': colorBlindMode.name,
      });
    }
    notifyListeners();
  }

  Future<void> completeLogin(UserProfile userProfile) async {
    profile = userProfile;
    loggedIn = true;
    await prefsService.setSession(loggedIn: true, uid: userProfile.uid);
    achievements = await achievementsService.loadAll(userProfile.uid);
    notifyListeners();
  }

  Future<void> logout() async {
    await authService.signOut();
    await prefsService.setSession(loggedIn: false);
    loggedIn = false;
    profile = null;
    notifyListeners();
  }

  Future<void> unlockAchievement(String id) async {
    final match = achievements.where((a) => a.id == id);
    if (match.isEmpty) return;
    final achievement = match.first;
    final justNow = await achievementsService.unlock(profile?.uid, achievement);
    if (justNow) {
      justUnlocked = achievement;
      notifyListeners();
    }
  }

  void clearJustUnlocked() {
    justUnlocked = null;
  }
}
