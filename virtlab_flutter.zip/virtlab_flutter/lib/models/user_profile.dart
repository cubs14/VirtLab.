class UserProfile {
  final String uid;
  final String username;
  final String email;
  final String photoUrl;
  final int level;
  final int xp;

  const UserProfile({
    required this.uid,
    required this.username,
    required this.email,
    required this.photoUrl,
    this.level = 1,
    this.xp = 0,
  });

  factory UserProfile.fromMap(String uid, Map<String, dynamic> map) {
    return UserProfile(
      uid: uid,
      username: map['username'] ?? '',
      email: map['email'] ?? '',
      photoUrl: map['photoUrl'] ?? '',
      level: map['level'] ?? 1,
      xp: map['xp'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() => {
        'username': username,
        'email': email,
        'photoUrl': photoUrl,
        'level': level,
        'xp': xp,
      };

  UserProfile copyWith({String? photoUrl, int? level, int? xp}) => UserProfile(
        uid: uid,
        username: username,
        email: email,
        photoUrl: photoUrl ?? this.photoUrl,
        level: level ?? this.level,
        xp: xp ?? this.xp,
      );
}
