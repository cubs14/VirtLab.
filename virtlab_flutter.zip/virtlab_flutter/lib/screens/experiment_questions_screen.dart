import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/experiment.dart';
import '../state/app_state.dart';
import 'labi_chat_screen.dart';

/// Pantalla de preguntas del experimento (Q_Preguntas / F_Preguntas /
/// B_Preguntas), ahora de OPCIÓN MÚLTIPLE en vez de texto libre.
///
/// Reglas conservadas del original:
/// - No deja continuar si falta alguna respuesta.
/// - Si el usuario elige "No estoy seguro/a" en cualquier pregunta,
///   se desbloquea el logro "No idea" (antes se detectaba con la
///   frase "no sé" en texto libre; ahora es una opción explícita).
/// - Si tarda más de 3 minutos respondiendo, se desbloquea "Sin
///   prisa" (logro_lento).
/// - Al finalizar se desbloquea "Primer experimento de <ciencia>"
///   (solo la primera vez) y se pasa a Labi, que ahora también recibe
///   el puntaje de aciertos para dar mejor retroalimentación.
class ExperimentQuestionsScreen extends StatefulWidget {
  final Subject subject;
  final Experiment experiment;
  final ValueNotifier<bool> completedNotifier;

  const ExperimentQuestionsScreen({
    super.key,
    required this.subject,
    required this.experiment,
    required this.completedNotifier,
  });

  @override
  State<ExperimentQuestionsScreen> createState() => _ExperimentQuestionsScreenState();
}

class _ExperimentQuestionsScreenState extends State<ExperimentQuestionsScreen> {
  late final List<int?> _selected;
  late final DateTime _startedAt;
  String? _error;

  @override
  void initState() {
    super.initState();
    _selected = List<int?>.filled(widget.experiment.questions.length, null);
    _startedAt = DateTime.now();
  }

  Future<void> _finish() async {
    if (_selected.any((s) => s == null)) {
      setState(() => _error = 'Completa todas las respuestas antes de continuar');
      return;
    }
    setState(() => _error = null);

    final state = context.read<AppState>();
    final elapsed = DateTime.now().difference(_startedAt);
    final questions = widget.experiment.questions;

    var correctCount = 0;
    var saidUnsure = false;
    for (var i = 0; i < questions.length; i++) {
      final chosen = _selected[i]!;
      if (chosen == questions[i].unsureIndex) saidUnsure = true;
      if (chosen == questions[i].correctIndex) correctCount++;
    }

    if (saidUnsure) {
      await state.unlockAchievement('logro_no_idea');
    }
    if (elapsed > const Duration(minutes: 3)) {
      await state.unlockAchievement('logro_lento');
    }
    await state.unlockAchievement('logro_${widget.subject.achievementPrefix}_1');

    widget.completedNotifier.value = true; // no cuenta como "me rindo"

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => LabiChatScreen(
          experiment: widget.experiment,
          correctCount: correctCount,
          totalQuestions: questions.length,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final exp = widget.experiment;
    return Scaffold(
      appBar: AppBar(title: const Text('Responde las siguientes preguntas')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            for (var i = 0; i < exp.questions.length; i++) ...[
              Text(exp.questions[i].text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              ...List.generate(exp.questions[i].options.length, (optIndex) {
                final option = exp.questions[i].options[optIndex];
                final isSelected = _selected[i] == optIndex;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Material(
                    color: isSelected ? Theme.of(context).colorScheme.primary.withOpacity(0.15) : Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => setState(() => _selected[i] = optIndex),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        child: Row(
                          children: [
                            Icon(
                              isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                              color: isSelected ? Theme.of(context).colorScheme.primary : Colors.black45,
                            ),
                            const SizedBox(width: 10),
                            Expanded(child: Text(option, style: const TextStyle(fontSize: 15))),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }),
              const SizedBox(height: 14),
            ],
            if (_error != null) ...[
              Text(_error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 12),
            ],
            ElevatedButton(onPressed: _finish, child: const Text('Finalizar')),
          ],
        ),
      ),
    );
  }
}
