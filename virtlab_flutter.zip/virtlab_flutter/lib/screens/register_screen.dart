import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user_profile.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import 'personalize_screen.dart';

/// Pantalla "Crear cuenta", simplificada a solo lo esencial: nombre
/// de usuario (con el que Labi y los logros felicitan al usuario),
/// correo electrónico y contraseña.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();

  bool _loading = false;
  String? _error;

  /// Avatar por defecto para todos los usuarios (la foto de perfil
  /// personalizada queda para una actualización futura, ya que
  /// requiere Firebase Storage con el plan Blaze).
  static const _defaultAvatar = 'assets/images/default_avatar.png';

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_password.text != _confirm.text) {
      setState(() => _error = 'Las contraseñas no coinciden.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    final state = context.read<AppState>();
    try {
      final user = await state.authService.register(_email.text, _password.text);
      if (user == null) throw Exception('No se pudo crear la cuenta.');

      final profile = UserProfile(
        uid: user.uid,
        username: _username.text.trim(),
        email: _email.text.trim(),
        photoUrl: _defaultAvatar,
      );
      await state.firestoreService.createUserProfile(profile);
      await state.completeLogin(profile);

      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const PersonalizeScreen(firstTime: true)),
        (route) => false,
      );
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Crear cuenta'), foregroundColor: AppColors.contrastFor(state.buttonColor)),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: CircleAvatar(
                    radius: 48,
                    backgroundColor: Colors.white,
                    backgroundImage: const AssetImage(_defaultAvatar),
                  ),
                ),
                const SizedBox(height: 20),
                _field(_username, 'Nombre de usuario'),
                _field(_email, 'Correo electrónico', keyboardType: TextInputType.emailAddress),
                _field(_password, 'Contraseña', obscure: true),
                _field(_confirm, 'Confirmar contraseña', obscure: true),
                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(_error!, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _loading ? null : _submit,
                  child: _loading
                      ? const SizedBox(
                          height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Crear cuenta'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {bool obscure = false, TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        obscureText: obscure,
        keyboardType: keyboardType,
        decoration: InputDecoration(labelText: label, filled: true, fillColor: Colors.white),
        validator: (v) => (v == null || v.isEmpty) ? 'Requerido' : null,
      ),
    );
  }
}
