import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

/// Términos y Condiciones de VirtLab, y explicación de por qué se
/// pide crear una cuenta.
class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Términos y condiciones'),
        foregroundColor: AppColors.contrastFor(state.buttonColor),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: const [
            _Section(
              title: '1. Qué es VirtLab',
              body:
                  'VirtLab es una aplicación educativa para descubrir, experimentar '
                  'y comprender ciencias naturales (Química, Física y Biología) a '
                  'través de experimentos guiados, preguntas y un sistema de logros.',
            ),
            _Section(
              title: '2. Por qué te pedimos crear una cuenta',
              body:
                  'Creamos una cuenta para ti porque VirtLab guarda tu progreso, tus '
                  'logros desbloqueados, tu nivel/XP y tus preferencias de '
                  'personalización (colores, tamaño de texto, ajustes de '
                  'daltonismo). Sin una cuenta, todo eso se perdería cada vez que '
                  'cierres la aplicación o cambies de dispositivo. La cuenta es '
                  'también lo que le permite a Labi (nuestro asistente) saludarte '
                  'por tu nombre de usuario y felicitarte por tus logros.',
            ),
            _Section(
              title: '3. Qué información guardamos',
              body:
                  '• Tu nombre de usuario y correo electrónico (para iniciar sesión).\n'
                  '• Tu foto de perfil, si decides subir una.\n'
                  '• Tu progreso: experimentos completados, respuestas de opción '
                  'múltiple, logros desbloqueados, nivel y XP.\n'
                  '• Tus preferencias de personalización de la app.\n\n'
                  'No pedimos ni guardamos datos innecesarios como tu ubicación '
                  'en tiempo real, contactos, ni información financiera.',
            ),
            _Section(
              title: '4. Cómo usamos tu información',
              body:
                  'Tu información se usa únicamente para que VirtLab funcione: '
                  'mostrarte tu progreso, sincronizarlo entre dispositivos, y '
                  'personalizar tu experiencia dentro de la app. No vendemos ni '
                  'compartimos tu información con terceros con fines publicitarios.',
            ),
            _Section(
              title: '5. Asistente Labi (inteligencia artificial)',
              body:
                  'Cuando chateas con Labi, el texto que escribes se envía a un '
                  'servicio externo de inteligencia artificial para generar una '
                  'respuesta. Evita compartir con Labi información personal '
                  'sensible que no necesites compartir.',
            ),
            _Section(
              title: '6. Uso apropiado',
              body:
                  'VirtLab está pensada para el aprendizaje. Te pedimos usar '
                  'nombres de usuario y contenido respetuoso, y no intentar dañar '
                  'el funcionamiento de la aplicación o el de otros usuarios.',
            ),
            _Section(
              title: '7. Tus derechos sobre tu información',
              body:
                  'Puedes cerrar sesión en cualquier momento desde tu Perfil. Si '
                  'quieres que eliminemos tu cuenta y tus datos por completo, '
                  'puedes solicitarlo contactando al equipo de VirtLab.',
            ),
            _Section(
              title: '8. Cambios a estos términos',
              body:
                  'Estos términos pueden actualizarse a medida que VirtLab agregue '
                  'nuevas funciones. Los cambios importantes se avisarán dentro de '
                  'la aplicación.',
            ),
            SizedBox(height: 8),
            Text(
              'Al crear una cuenta en VirtLab, confirmas que entiendes y aceptas '
              'estos términos.',
              style: TextStyle(fontStyle: FontStyle.italic, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final String body;
  const _Section({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(body, style: const TextStyle(fontSize: 15, height: 1.4)),
        ],
      ),
    );
  }
}
