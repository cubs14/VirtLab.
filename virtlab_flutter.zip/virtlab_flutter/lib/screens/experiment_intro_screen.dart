import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/experiment.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import 'experiment_questions_screen.dart';

/// Pantalla de introducción de un experimento: título, materiales y
/// pasos en formato de checklist (equivalente a Q_Intro / F_Intro /
/// B_Intro del original). Si el usuario sale de aquí sin llegar a
/// "Finalizar" el cuestionario, se desbloquea el logro "Me rindo".
class ExperimentIntroScreen extends StatefulWidget {
  final Subject subject;
  final Experiment experiment;
  const ExperimentIntroScreen({super.key, required this.subject, required this.experiment});

  @override
  State<ExperimentIntroScreen> createState() => _ExperimentIntroScreenState();
}

class _ExperimentIntroScreenState extends State<ExperimentIntroScreen> {
  final ValueNotifier<bool> _completed = ValueNotifier(false);

  @override
  void dispose() {
    if (!_completed.value) {
      context.read<AppState>().unlockAchievement('logro_me_rindo');
    }
    _completed.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final exp = widget.experiment;
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      appBar: AppBar(title: Text(widget.subject.label), foregroundColor: AppColors.contrastFor(primary)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Text(exp.title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            const Text('Materiales', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...exp.materials.map((m) => _ChecklistRow(text: m, icon: Icons.check_circle_outline, color: primary)),
            const SizedBox(height: 24),
            const Text('Pasos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...exp.steps.asMap().entries.map(
                  (e) => _ChecklistRow(text: e.value, number: e.key + 1, color: primary),
                ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ExperimentQuestionsScreen(
                      subject: widget.subject,
                      experiment: exp,
                      completedNotifier: _completed,
                    ),
                  ),
                );
              },
              child: const Text('Siguiente'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Fila de checklist reutilizada para materiales (con ícono) y pasos
/// (con número).
class _ChecklistRow extends StatelessWidget {
  final String text;
  final IconData? icon;
  final int? number;
  final Color color;

  const _ChecklistRow({required this.text, required this.color, this.icon, this.number});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (icon != null)
            Icon(icon, color: color, size: 22)
          else
            Container(
              width: 22,
              height: 22,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: Text(
                '$number',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
              ),
            ),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
