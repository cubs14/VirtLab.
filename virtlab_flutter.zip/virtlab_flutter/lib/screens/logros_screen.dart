import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/achievement_tile.dart';

class LogrosScreen extends StatelessWidget {
  const LogrosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    // Los logros marcados como "hidden" (secretos) no aparecen aquí
    // -ni siquiera en gris/bloqueados- hasta que se desbloquean por
    // primera vez. Así el logro "El tiempo perdido" permanece
    // invisible hasta que alguien realmente vuelve tras 3 semanas.
    final visible = state.achievements.where((a) => !a.hidden || a.unlocked).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('🏆 Logros 🏆'),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: visible.map((a) => AchievementTile(achievement: a)).toList(),
      ),
    );
  }
}
