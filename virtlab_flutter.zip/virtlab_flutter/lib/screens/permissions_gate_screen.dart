import 'package:flutter/material.dart';
import '../services/permissions_service.dart';
import '../theme/app_theme.dart';

/// Pantalla que se muestra justo después del Splash mientras la app
/// todavía no tenga concedidos los permisos de cámara/galería y de
/// notificaciones. Pide ambos con una explicación clara antes de
/// continuar al flujo normal (Bienvenida o Menú).
///
/// Esta pantalla NO bloquea el uso general de la app si el usuario
/// decide no conceder algo aquí (puede tocar "Ahora no, continuar").
/// Lo que sí queda bloqueado hasta que conceda cámara y galería es,
/// específicamente, cambiar la foto de perfil — ver ProfileScreen,
/// que vuelve a pedir el permiso cada vez que se toca la foto.
class PermissionsGateScreen extends StatefulWidget {
  final Widget next;
  const PermissionsGateScreen({super.key, required this.next});

  @override
  State<PermissionsGateScreen> createState() => _PermissionsGateScreenState();
}

class _PermissionsGateScreenState extends State<PermissionsGateScreen> {
  final _permissions = PermissionsService();
  bool _requestingMedia = false;
  bool _requestingNotifications = false;
  bool? _mediaGranted;
  bool? _notificationsGranted;

  @override
  void initState() {
    super.initState();
    _refreshStatus();
  }

  Future<void> _refreshStatus() async {
    final media = await _permissions.mediaGranted;
    final notifications = await _permissions.notificationsGranted;
    if (!mounted) return;
    setState(() {
      _mediaGranted = media;
      _notificationsGranted = notifications;
    });
  }

  Future<void> _askMedia() async {
    setState(() => _requestingMedia = true);
    await _permissions.requestMedia();
    await _refreshStatus();
    if (mounted) setState(() => _requestingMedia = false);
  }

  Future<void> _askNotifications() async {
    setState(() => _requestingNotifications = true);
    await _permissions.requestNotifications();
    await _refreshStatus();
    if (mounted) setState(() => _requestingNotifications = false);
  }

  void _continue() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => widget.next),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mediaOk = _mediaGranted == true;
    final notificationsOk = _notificationsGranted == true;
    final allOk = mediaOk && notificationsOk;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.shield_outlined, size: 60, color: AppColors.primaryDark),
              const SizedBox(height: 16),
              const Text(
                'Antes de empezar',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              const Text(
                'VirtLab necesita un par de permisos para darte la mejor experiencia.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.black54),
              ),
              const SizedBox(height: 28),
              _PermissionCard(
                icon: Icons.photo_camera_outlined,
                title: 'Cámara y galería',
                description:
                    'Para poder tomarte o elegir una foto de perfil cuando quieras.',
                granted: mediaOk,
                loading: _requestingMedia,
                onTap: _askMedia,
              ),
              const SizedBox(height: 16),
              _PermissionCard(
                icon: Icons.notifications_active_outlined,
                title: 'Notificaciones',
                description:
                    'Para avisarte de tus logros y recordarte volver a tus experimentos.',
                granted: notificationsOk,
                loading: _requestingNotifications,
                onTap: _askNotifications,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _continue,
                  child: Text(allOk ? 'Continuar' : 'Ahora no, continuar'),
                ),
              ),
              if (!allOk) ...[
                const SizedBox(height: 10),
                const Text(
                  'Podrás activarlos más tarde. Eso sí: para cambiar tu foto de '
                  'perfil vas a necesitar conceder cámara y galería.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.black45),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _PermissionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final bool granted;
  final bool loading;
  final VoidCallback onTap;

  const _PermissionCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.granted,
    required this.loading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 3)),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, size: 30, color: AppColors.primaryDark),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(description, style: const TextStyle(fontSize: 12.5, color: Colors.black54)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          if (loading)
            const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          else if (granted)
            const Icon(Icons.check_circle, color: AppColors.primary, size: 26)
          else
            OutlinedButton(onPressed: onTap, child: const Text('Permitir')),
        ],
      ),
    );
  }
}
