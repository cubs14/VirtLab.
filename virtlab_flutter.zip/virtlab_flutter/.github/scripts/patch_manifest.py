#!/usr/bin/env python3
"""Agrega al AndroidManifest.xml los permisos nativos que VirtLab
necesita: cámara y galería (foto de perfil).

Se ejecuta en GitHub Actions justo después de `flutter create`, ya
que la carpeta android/ NO se guarda en el repositorio (se genera de
cero en cada build, ver README) y por lo tanto no se puede editar el
manifiesto a mano de una vez para siempre.

Es idempotente: si se corre dos veces no duplica nada.
"""
import re
from pathlib import Path

MANIFEST = Path("android/app/src/main/AndroidManifest.xml")

PERMISSIONS = (
    '    <uses-permission android:name="android.permission.CAMERA" />\n'
    '    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />\n'
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" '
    'android:maxSdkVersion="32" />\n'
)


def main() -> None:
    text = MANIFEST.read_text(encoding="utf-8")

    if "android.permission.CAMERA" not in text:
        text = re.sub(
            r"(<manifest[^>]*>)",
            r"\1\n" + PERMISSIONS,
            text,
            count=1,
        )

    MANIFEST.write_text(text, encoding="utf-8")
    print("AndroidManifest.xml actualizado con permisos de cámara y galería.")


if __name__ == "__main__":
    main()
