/* =====================================================
   VirtLab — Lógica de cuenta regresiva
   -----------------------------------------------------
   - Calcula SIEMPRE (fecha_objetivo - fecha_actual_real)
     en cada carga de la página. No usa contadores
     internos ni depende de aperturas anteriores.
   - SI fecha_actual <  fecha_objetivo  -> cuenta regresiva
   - SI fecha_actual >= fecha_objetivo  -> estado final
     (si el usuario ya llegó tarde, se salta la animación
     "ES HOY" y va directo al video, tal como pide el brief).
   ===================================================== */

(function () {
  "use strict";

  // Fecha/hora objetivo: 18 de agosto de 2026, 00:00:00 (hora local del dispositivo)
  var TARGET = new Date(2026, 7, 18, 0, 0, 0, 0);

  var countdownScreen = document.getElementById("countdown-screen");
  var todayScreen = document.getElementById("today-screen");
  var finalScreen = document.getElementById("final-screen");

  var elDays = document.getElementById("days");
  var elHours = document.getElementById("hours");
  var elMinutes = document.getElementById("minutes");
  var elSeconds = document.getElementById("seconds");

  var video = document.getElementById("finalVideo");
  var unmuteBtn = document.getElementById("unmuteBtn");

  var tickInterval = null;

  function pad(n) {
    return String(n).padStart(2, "0");
  }

  function showScreen(screen) {
    [countdownScreen, todayScreen, finalScreen].forEach(function (s) {
      if (!s) return;
      s.classList.toggle("hidden", s !== screen);
    });
  }

  function renderTime(msRemaining) {
    var totalSeconds = Math.max(0, Math.floor(msRemaining / 1000));
    var days = Math.floor(totalSeconds / 86400);
    var hours = Math.floor((totalSeconds % 86400) / 3600);
    var minutes = Math.floor((totalSeconds % 3600) / 60);
    var seconds = totalSeconds % 60;

    elDays.textContent = pad(days);
    elHours.textContent = pad(hours);
    elMinutes.textContent = pad(minutes);
    elSeconds.textContent = pad(seconds);
  }

  function playFinalVideo() {
    if (!video) return;
    video.muted = true; // requisito de los navegadores para autoplay
    var playPromise = video.play();
    if (playPromise && typeof playPromise.catch === "function") {
      playPromise.catch(function () {
        // Autoplay bloqueado incluso silenciado: se reproducirá
        // al primer toque/clic del usuario en cualquier parte.
        var resume = function () {
          video.play().catch(function () {});
          document.removeEventListener("touchstart", resume);
          document.removeEventListener("click", resume);
        };
        document.addEventListener("touchstart", resume, { once: true });
        document.addEventListener("click", resume, { once: true });
      });
    }
    if (unmuteBtn) {
      unmuteBtn.classList.remove("hidden");
      unmuteBtn.addEventListener("click", function () {
        video.muted = !video.muted;
        unmuteBtn.textContent = video.muted ? "🔇 Activar sonido" : "🔊 Sonido activado";
        video.play().catch(function () {});
      });
    }
  }

  function goToFinalState() {
    showScreen(finalScreen);
    playFinalVideo();
  }

  function playTodayTransitionThenFinal() {
    showScreen(todayScreen);
    // Animación "ES HOY" visible unos segundos antes del video.
    window.setTimeout(goToFinalState, 3200);
  }

  function tick() {
    var now = new Date();
    var diff = TARGET.getTime() - now.getTime();

    if (diff <= 0) {
      clearInterval(tickInterval);
      playTodayTransitionThenFinal();
      return;
    }
    renderTime(diff);
  }

  function init() {
    var now = new Date();
    var diff = TARGET.getTime() - now.getTime();

    if (diff <= 0) {
      // La página se abre en o después del evento: estado final directo,
      // sin volver a mostrar nunca la cuenta regresiva.
      goToFinalState();
      return;
    }

    // Aún falta tiempo: mostrar y actualizar la cuenta regresiva en vivo.
    showScreen(countdownScreen);
    renderTime(diff);
    tickInterval = window.setInterval(tick, 1000);
  }

  document.addEventListener("DOMContentLoaded", init);

  // Si el usuario deja la pestaña abierta y vuelve (cambio de pestaña,
  // dispositivo suspendido, etc.), se recalcula con la hora real actual.
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && tickInterval !== null) {
      tick();
    }
  });
})();
