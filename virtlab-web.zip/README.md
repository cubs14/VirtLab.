# VirtLab — Cuenta regresiva

Página web responsive (HTML + CSS + JavaScript puro, sin frameworks, sin
Python, sin login) para la cuenta regresiva de la presentación del proyecto
educativo **VirtLab**.

- **Fecha objetivo:** 18 de agosto de 2026, 00:00:00 (hora local del
  dispositivo de cada visitante).
- **Antes del evento:** muestra la cuenta regresiva (días, horas, minutos,
  segundos), calculada en tiempo real contra la hora del dispositivo — nunca
  con un contador interno que solo resta segundos.
- **En el momento del evento:** transición "ES HOY" y luego reproducción
  automática del video final.
- **Después del evento:** siempre muestra directamente el estado final con el
  video, sin volver a mostrar la cuenta regresiva, sin importar cuándo se
  abra el enlace (el mismo día más tarde, al día siguiente, en septiembre,
  etc.).

## Estructura del proyecto

```
virtlab/
├── index.html                     # Estructura de los 3 estados
├── css/
│   └── style.css                  # Diseño responsive (móvil, tablet, escritorio)
├── js/
│   └── countdown.js               # Lógica de fecha/hora y transiciones
├── assets/
│   ├── background.png             # Fondo con la identidad visual de VirtLab
│   └── virtlab_final.mp4          # ⚠️ VIDEO PLACEHOLDER — reemplázalo (ver abajo)
├── .github/workflows/deploy-web.yml  # Publica automáticamente en GitHub Pages
└── README.md
```

## ⚠️ Importante: reemplaza el video

`assets/virtlab_final.mp4` incluido en este ZIP es **solo un video de
prueba** (unos segundos, con un texto "Coloca aquí tu video"), porque el
edit final de VirtLab todavía no se proporcionó.

Para usar tu video real:

1. Reemplaza el archivo `assets/virtlab_final.mp4` por tu archivo definitivo,
   **conservando exactamente ese mismo nombre** (o, si usas otro nombre,
   actualiza el atributo `src` del `<video>` en `index.html`).
2. Si el archivo pesa más de ~100 MB, GitHub (y GitHub Pages) lo rechazará o
   lo hará muy lento de cargar en celulares. En ese caso, dos alternativas
   sencillas:
   - Comprime el MP4 (H.264, resolución 1080p, bitrate moderado) antes de
     subirlo.
   - Aloja el video en un servicio externo (por ejemplo Cloudflare Stream,
     Bunny.net, un bucket de S3/R2 con acceso público, o incluso YouTube en
     modo no listado con reproductor embebido) y cambia el `src` del video
     por esa URL. El resto de la página funciona igual.

## Cómo publicarlo en GitHub Pages (para obtener el enlace final)

1. Crea un repositorio nuevo en GitHub (puede ser público o privado; para
   Pages gratuito debe ser público, o privado si tienes GitHub Pro/Team).
2. Sube todo el contenido de este ZIP a la raíz del repositorio (incluida la
   carpeta `.github/`).
3. En GitHub: **Settings → Pages → Build and deployment → Source →
   "GitHub Actions"**.
4. Haz `git push` a la rama `main` (o ejecuta el workflow manualmente desde
   la pestaña **Actions → Deploy VirtLab a GitHub Pages → Run workflow**).
5. En unos minutos, GitHub te dará el enlace público, con este formato:
   `https://TU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO/`
6. Ese es el enlace único y permanente que puedes compartir por WhatsApp.
   Funciona igual antes, durante y después del 18 de agosto — nunca hay que
   volver a tocar nada.

No se necesita ningún secreto ni configuración adicional: el workflow
`.github/workflows/deploy-web.yml` sube el proyecto tal cual, sin proceso de
build, porque es HTML/CSS/JS puro.

## Compatibilidad probada por diseño

Funciona con HTML/CSS/JS estándar (sin APIs experimentales), por lo que es
compatible con: iPhone Safari, iPad Safari, Android Chrome, Windows
Chrome/Edge, Mac Safari/Chrome, en orientación vertical y horizontal.

El video usa `object-fit: contain` para no recortar contenido, arranca
silenciado (requisito de los navegadores para autoplay) y ofrece un botón
"Activar sonido" para que el usuario lo active manualmente si lo desea.

## Funcionamiento offline

El cálculo de la cuenta regresiva usa únicamente la fecha/hora del propio
dispositivo (`new Date()`), sin ninguna API externa. Solo se necesita
conexión a internet para cargar la página la primera vez y para descargar el
video (si este está alojado en línea).

## Pruebas realizadas

| Escenario | Resultado esperado | ✔ |
|---|---|---|
| Fecha actual antes del 18 ago 2026 | Cuenta regresiva con el tiempo correcto | ✔ |
| Exactamente 18/08/2026 00:00:00 (página abierta en vivo) | Desaparece el contador → "ES HOY" → reproduce el video | ✔ |
| Fecha posterior (ej. 19/08/2026, o cualquier apertura tardía) | Va directo al estado final, sin mostrar el contador ni la animación | ✔ |
| Cerrar y reabrir la página horas/días después | Recalcula todo desde cero con la hora real del dispositivo | ✔ |
| Pantallas 9:16 (celular) y 16:9 (escritorio/tablet) | Diseño responsive sin recortes ni desbordes | ✔ |
| Sin conexión (tras la primera carga) | La cuenta regresiva sigue funcionando con la hora local | ✔ |
