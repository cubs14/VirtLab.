import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Un turno de la conversación con Labi.
class ChatTurn {
  final bool fromUser;
  final String text;
  const ChatTurn({required this.fromUser, required this.text});
}

/// LABI — el asistente inteligente oficial de VirtLab, con Groq
/// (modelos Llama de Meta, gratis, sin tarjeta de crédito) como motor
/// de IA.
///
/// ⚠️ La API key de Groq NUNCA vive en este archivo ni en ningún otro
/// archivo fuente. Se recibe únicamente al momento de compilar:
///
///   flutter build apk --release --dart-define=GROQ_API_KEY=tu_key
///
/// En GitHub Actions esa key se guarda como Secret del repositorio
/// (Settings → Secrets and variables → Actions → GROQ_API_KEY) y el
/// workflow se la pasa al compilador con --dart-define.
class LabiService {
  static const String _apiKey = String.fromEnvironment('GROQ_API_KEY');
  static const String _model = 'llama-3.3-70b-versatile';
  static const String _endpoint = 'https://api.groq.com/openai/v1/chat/completions';

  /// Cuántos turnos recientes de la conversación se envían — se
  /// limita para no gastar de más en conversaciones largas.
  static const int _maxHistoryTurns = 12;

  static const String _systemPrompt = '''
Eres LABI, el asistente oficial de VirtLab.

Tu misión es ayudar a los estudiantes a descubrir, experimentar y comprender la ciencia de forma sencilla, divertida y segura.

Explica los conceptos utilizando ejemplos fáciles.

Motiva al usuario a seguir aprendiendo.

Nunca respondas de forma ofensiva.

Nunca inventes datos científicos.

Si no conoces una respuesta indícalo con honestidad.

Siempre mantén un tono amigable y educativo.''';

  /// Mensaje inicial de Labi al terminar un experimento.
  Future<String> getInitialFeedback({
    required String experimentTitle,
    required int correctCount,
    required int totalQuestions,
  }) {
    final prompt =
        'Acabo de completar el experimento "$experimentTitle" en VirtLab '
        'y acerté $correctCount de $totalQuestions preguntas. Dame una '
        'felicitación breve y motivadora, y si fallé algo anímame a '
        'repasarlo, en un tono cercano y en español.';
    return sendMessage([ChatTurn(fromUser: true, text: prompt)]);
  }

  /// Continúa la conversación: manda el historial reciente para que
  /// Labi tenga contexto, igual que cualquier chat de IA.
  Future<String> sendMessage(List<ChatTurn> history) async {
    if (_apiKey.isEmpty) {
      return 'Todavía no tengo configurada mi clave de acceso a Groq. '
          'Pídele al desarrollador que la agregue en la configuración de '
          'compilación para poder responderte. 🔧';
    }

    final recent = history.length > _maxHistoryTurns
        ? history.sublist(history.length - _maxHistoryTurns)
        : history;

    final messages = [
      {'role': 'system', 'content': _systemPrompt},
      ...recent.map((t) => {'role': t.fromUser ? 'user' : 'assistant', 'content': t.text}),
    ];

    try {
      final response = await http
          .post(
            Uri.parse(_endpoint),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $_apiKey',
            },
            body: jsonEncode({
              'model': _model,
              'messages': messages,
              'temperature': 0.7,
            }),
          )
          .timeout(const Duration(seconds: 25));

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
        final choices = data['choices'] as List<dynamic>?;
        if (choices == null || choices.isEmpty) return _fallbackEmpty();
        final text = (choices.first['message']?['content'] as String?)?.trim();
        if (text == null || text.isEmpty) return _fallbackEmpty();
        return text;
      }

      if (response.statusCode == 401 || response.statusCode == 403) {
        return 'No pude conectarme con Groq — puede que la clave de '
            'configuración no sea válida. Avísale al desarrollador. 🔑';
      }
      if (response.statusCode == 429) {
        return 'Estoy recibiendo demasiadas preguntas de golpe. Espera '
            'un momento e inténtalo de nuevo. ⏳';
      }
      return '${_fallbackConnection()}\n\n(detalle técnico temporal: HTTP ${response.statusCode} — '
          '${response.body.length > 200 ? response.body.substring(0, 200) : response.body})';
    } on TimeoutException {
      return _fallbackConnection();
    } catch (e) {
      return '${_fallbackConnection()}\n\n(detalle técnico temporal: $e)';
    }
  }

  String _fallbackConnection() =>
      'LABI necesita conexión a internet para responder. Verifica tu '
      'conexión e inténtalo de nuevo. 📶';

  String _fallbackEmpty() =>
      'Hmm, no logré pensar en una buena respuesta para eso. ¿Puedes '
      'reformular tu pregunta? 🤔';
}
