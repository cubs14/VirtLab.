# VirtLab — Flutter (migrado desde Kodular/App Inventor)

## Qué es esto

Todo el código Dart (`lib/`) está completo: las 14 pantallas del flujo
completo (Splash → Bienvenida → Login/Registro → Personalización →
Menú → Química/Física/Biología → Preguntas → Labi → Logros → Perfil →
Acerca de), con el contenido real de los 14 experimentos migrado
textualmente del `.aia` original, más autenticación, Firestore,
Storage, FCM, personalización con vista previa en vivo, daltonismo y
sistema de logros funcional (incluye el logro "Sin prisa" que en el
original estaba a medio implementar).

## Lo que NO pude hacer en este entorno (y por qué)

Este chat no tiene acceso a internet ni al SDK de Flutter/Android, así
que **no pude**:

1. Correr `flutter create` para generar las carpetas nativas
   `android/` e `ios/` — este proyecto solo trae `lib/`, `pubspec.yaml`
   y `assets/`, no una app Android compilable todavía.
2. Correr `flutter pub get` (no hay red para bajar los paquetes).
3. Compilar, probar en un dispositivo/emulador, ni generar el APK
   final — la Fase 4 (Pruebas) y Fase 5 (Generar APK) de tu
   especificación quedan pendientes de correr de tu lado.
4. Configurar Authentication/Firestore/Storage en la consola real de
   Firebase — el `google-services.json` que subiste solo tiene la API
   key del proyecto `labi-2622a`, sin Auth ni reglas configuradas.

## Antes de compilar — configura Appwrite Storage (foto de perfil)

La foto de perfil se sube a Appwrite Storage (gratis, sin tarjeta,
sin Firebase Storage).

1. Crea una cuenta gratis en [cloud.appwrite.io](https://cloud.appwrite.io).
2. Crea un proyecto nuevo. En Project Settings copia el **Project
   ID** y el **endpoint** de tu región (ej.
   `https://fra.cloud.appwrite.io/v1`).
3. Ve a **Storage → Create bucket**. Copia el **Bucket ID**.
4. Dentro del bucket, en **Settings → Permissions**, agrega Role =
   "Any" con "Read" activado (así cualquiera puede ver las fotos ya
   subidas).
5. Ve a **Overview → Integrations → API Keys → Create API Key**, con
   scope `files.write` (y `files.read`). Copia esa key.
6. Abre `lib/config/appwrite_config.dart` en el zip y reemplaza
   `TU_ENDPOINT_AQUI`, `TU_PROJECT_ID_AQUI` y `TU_BUCKET_ID_AQUI` con
   tus valores (estos tres NO son secretos).
7. En GitHub: **Settings → Secrets and variables → Actions → New
   repository secret** → nombre `APPWRITE_API_KEY` → pega la key del
   paso 5 (esta sí es secreta, nunca va en el código).

## Opción A — Compilar el APK en la nube con GitHub Actions (sin instalar nada)

Ya incluí el workflow en `.github/workflows/build-apk.yml`. Pasos:

1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube
   **todo** el contenido de este zip tal cual (arrastra la carpeta
   completa en la web de GitHub, o usa `git push` si tienes Git).
2. En el repo: **Settings → Secrets and variables → Actions → New
   repository secret**.
   - Nombre: `GOOGLE_SERVICES_JSON_BASE64`
   - Valor: pega el contenido del archivo `google-services-base64.txt`
     que te compartí junto con este zip (ya es tu `google-services.json`
     real, codificado en base64 — el workflow lo decodifica solo).
3. Ve a **[Firebase Console](https://console.firebase.google.com)** → tu proyecto ("labi") →
   **Build → AI Logic** → **Get started** → elige **"Gemini Developer API"**
   (tiene capa gratuita) → sigue el asistente hasta que quede activado.
   Ya no necesitas crear ningún secreto de API key para Labi — Firebase
   AI Logic no requiere que la app cargue ninguna key.
4. La app usa Firebase **App Check** (proveedor "debug", pensado para
   estos APK de prueba). La primera vez que abras Labi en el celular,
   si App Check está en modo "Enforced" en la consola, puede que el
   mensaje de error te muestre un token de depuración — cópialo y
   regístralo en **Firebase Console → Project settings → App Check
   → Apps → (tu app Android) → Manage debug tokens**. Si prefieres
   evitarte este paso mientras pruebas, pon App Check en modo
   **"Unenforced"/"Monitor only"** temporalmente desde esa misma
   pantalla, y actívalo estricto ("Enforced") solo cuando publiques
   la versión final en Play Store.
5. Ve a la pestaña **Actions** del repo → selecciona "Build VirtLab
   APK" → **Run workflow**.
6. Cuando termine (unos 5-8 minutos), entra a esa ejecución y baja el
   artefacto **virtlab-apk** — ahí está tu `app-release.apk`, listo
   para instalar en cualquier Android.

Nota: el APK saldrá firmado con la clave de debug de Flutter, lo cual
es perfecto para probar en cualquier dispositivo. Para publicarlo en
Google Play vas a necesitar firmarlo con tu propio keystore de
producción (te ayudo con eso cuando llegues a ese paso).

## Opción B — Compilarlo tú localmente

```bash
# 1. Descomprime este zip y entra a la carpeta
cd virtlab_flutter

# 2. Genera las carpetas nativas SIN pisar lib/ ni pubspec.yaml
flutter create --org com.virtlab --project-name virtlab .

# 3. Copia tu google-services.json real a android/app/google-services.json

# 4. En android/build.gradle añade el classpath de Google services,
#    y en android/app/build.gradle aplica el plugin
#    com.google.gms.google-services (guía oficial de FlutterFire).

# 5. Instala dependencias
flutter pub get

# 6. Compila el APK
flutter build apk --release
```

## Cosas que necesitan una decisión tuya antes de producción

- **API key de Gemini expuesta**: el `.aia` original traía la key de
  Gemini escrita en texto plano. No la reutilicé en este código —
  debes regenerarla en Google AI Studio y, en vez de llamarla
  directo desde el cliente, desplegar una Cloud Function que la
  guarde como secreto de servidor. `lib/services/labi_service.dart`
  ya está escrito para llamar a esa función; falta desplegarla.
- **Logro "Sin prisa" (logro_lento)**: en el proyecto original ese tag
  se leía/escribía pero nunca tuvo tarjeta ni condición visible en
  Logros. Implementé una condición razonable (tardar más de 3 minutos
  respondiendo) inferida del temporizador que sí existía en
  Q_Preguntas — confírmala o ajústala si el equipo tenía otra idea.
- Los íconos `logrocolor_5/6/7/8/10.png` (y sus versiones gris) no
  corresponden a ningún logro definido en el proyecto original — están
  en `assets/` por si quieren usarlos para logros nuevos, pero no
  inventé nombres ni condiciones para ellos.

## Nuevo: permisos y logros de racha

Se agregaron tres cosas sobre el proyecto original:

### 1. Pantalla de permisos al inicio

Justo después del Splash (`lib/screens/permissions_gate_screen.dart`),
si la app no tiene ya concedidos cámara+galería, se muestra una
pantalla que los pide con una explicación clara. No
bloquea el resto de la app: el usuario puede tocar "Ahora no,
continuar" y seguir usando VirtLab con normalidad. Si ya los tenía
concedidos (arranques posteriores), esta pantalla se salta sola.

### 2. Bloqueo real de la foto de perfil sin permiso

En `lib/screens/profile_screen.dart`, tocar la foto de perfil ya NO
abre directamente el selector de cámara/galería: primero se comprueba
el permiso (`lib/services/permissions_service.dart`). Si falta, se
vuelve a pedir en ese mismo toque; si el usuario lo niega, no se abre
el selector, y la próxima vez que toque la foto se le vuelve a pedir,
así indefinidamente hasta que lo conceda. Si el usuario marcó "no
volver a preguntar" en el sistema, se le ofrece un botón directo a
Ajustes.

### 3. Dos logros nuevos

En `lib/data/achievements_data.dart`:

- **"Una semana en llamas"** (ícono 🔥 que me pasaste): se
  desbloquea al completar 7 días seguidos abriendo la app.
- **"El tiempo perdido"** (ícono ⏳ que me pasaste): logro **secreto**
  — no aparece en la pantalla de Logros (ni en gris/bloqueado) hasta
  desbloquearse. Se desbloquea si el usuario vuelve después de 3
  semanas completas (21 días) sin abrir VirtLab.

Ambos se calculan en `AppState._updateStreakAndAchievements()`
comparando la fecha de hoy contra la última vez que se abrió la app
(guardada en SharedPreferences vía `PreferencesService`), cada vez que
arranca la app. Funciona 100% offline, igual que el resto del sistema
de logros.

Estas tres cosas dependen de un paquete nuevo en `pubspec.yaml`
(`permission_handler`) y de permisos nativos de Android que **no**
viven en un `AndroidManifest.xml` fijo en el repo (recuerda:
`android/` no existe aquí, se genera en cada build de GitHub
Actions). Por eso se agregó `.github/scripts/patch_manifest.py`, que
el workflow `build-apk.yml` ejecuta justo después de `flutter create`
para inyectar `CAMERA`, `READ_MEDIA_IMAGES` y
`READ_EXTERNAL_STORAGE`. Si compilas localmente (Opción B), agrega
esos mismos permisos a mano en
`android/app/src/main/AndroidManifest.xml` (puedes copiarlos del
propio script).

En la versión **web** (`deploy-web.yml`) todo esto queda desactivado
automáticamente (permission_handler no tiene soporte real ahí):
`PermissionsService` siempre reporta "concedido" en web, para no
romper ni bloquear esa build.

## Versión Web — despliegue en Netlify

`.github/workflows/deploy-netlify.yml` compila la versión Web en
GitHub Actions y la publica directo en Netlify (no en GitHub Pages),
para que el link no incluya tu usuario de GitHub y puedas elegir el
nombre. El repo puede seguir siendo privado.

Necesita dos secrets en **Settings → Secrets and variables → Actions**
del repo:

- `NETLIFY_AUTH_TOKEN` — Netlify → tu avatar → User settings →
  Applications → Personal access tokens → New access token.
- `NETLIFY_SITE_ID` — Netlify → el sitio → Site configuration →
  General → Site ID. El nombre del link (`tu-nombre.netlify.app`) se
  cambia ahí mismo en "Change site name".

Luego, para publicar: **Actions → Deploy VirtLab Web (Netlify) → Run
workflow**.

**Limitación de este entorno:** no tengo Flutter/Dart ni acceso a red
aquí, así que no pude correr `flutter analyze` ni
`flutter build web` para verificar esta versión — la compilación real
la hace GitHub Actions cuando corres el workflow.
