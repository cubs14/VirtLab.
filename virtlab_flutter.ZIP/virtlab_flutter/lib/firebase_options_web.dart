﻿import 'package:firebase_core/firebase_core.dart';

/// Configuración de Firebase específica para la versión web de
/// VirtLab. Android usa automáticamente google-services.json y no
/// necesita este archivo — pero la web sí necesita estos valores
/// explícitos para poder inicializar Firebase en el navegador.
///
/// Estos valores NO son secretos (a diferencia de una API key de
/// verdad): la "apiKey" de Firebase Web solo identifica tu proyecto;
/// la seguridad real la dan las reglas de Firestore/Storage y los
/// dominios autorizados, no esta key. Por eso puede ir directo en el
/// código, igual que el google-services.json de Android.
///
/// Cómo conseguir estos valores (una sola vez, gratis):
/// 1. Ve a Firebase Console → tu proyecto ("labi") → ⚙️ Configuración
///    del proyecto → pestaña "Tus apps".
/// 2. Toca el ícono "</>" (Web) para agregar una app web nueva.
///    Ponle un nombre (ej. "VirtLab Web") y regístrala.
/// 3. Firebase te muestra un bloque de código con estos mismos
///    nombres de campo (apiKey, authDomain, etc.) — copia cada valor
///    aquí abajo.
/// 4. Ve a Authentication → Settings → Authorized domains → Add
///    domain → agrega tu dominio de GitHub Pages (ej.
///    "tuusuario.github.io") para que el login funcione ahí.
const webFirebaseOptions = FirebaseOptions(
  apiKey: "AIzaSyCAJY4EUT4yEihpqNhsRXf4usGXw3YAdbk",
   authDomain: "labi-2622a.firebaseapp.com",
  projectId: "labi-2622a",
  storageBucket: "labi-2622a.firebasestorage.app",
   messagingSenderId: "671169082209",
  appId: "1:671169082209:web:5fd0010b61349137b8cb20",
);
