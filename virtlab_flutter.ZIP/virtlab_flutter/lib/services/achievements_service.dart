import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/achievement.dart';
import '../data/achievements_data.dart';
import 'firestore_service.dart';

/// Maneja el desbloqueo de logros con copia local (para funcionar sin
/// conexión) y sincronización automática a Firestore cuando hay
/// internet.
///
/// La copia local se guarda con una llave distinta POR CADA CUENTA
/// (uid) — así, si dos cuentas distintas usan el mismo dispositivo
/// (por ejemplo, alguien cierra sesión y crea una cuenta nueva), cada
/// una tiene su propia caja de logros y nunca se mezclan entre sí.
/// Antes se guardaban todas bajo una sola llave compartida por todo
/// el dispositivo, y por eso una cuenta nueva heredaba por error los
/// logros de la cuenta anterior.
class AchievementsService {
  static const _kLocalKeyPrefix = 'achievements_state_';
  final FirestoreService _firestore = FirestoreService();

  String _localKey(String uid) => '$_kLocalKeyPrefix$uid';

  Future<List<Achievement>> loadAll(String? uid) async {
    final achievements = buildDefaultAchievements();
    if (uid == null) return achievements;

    final prefs = await SharedPreferences.getInstance();

    // 1. Aplicar copia local de ESTA cuenta primero (funciona offline).
    final raw = prefs.getString(_localKey(uid));
    if (raw != null) {
      final Map<String, dynamic> local = jsonDecode(raw);
      for (final a in achievements) {
        final state = local[a.id] as Map<String, dynamic>?;
        if (state != null) a.applyState(state);
      }
    }

    // 2. Traer/mezclar con Firestore, de la misma cuenta.
    try {
      final remote = await _firestore.getAllAchievementStates(uid);
      for (final a in achievements) {
        final state = remote[a.id];
        if (state != null) {
          final remoteUnlocked = state['unlocked'] as bool? ?? false;
          if (remoteUnlocked || a.unlocked) {
            a.applyState(state);
            a.unlocked = true;
          }
        }
      }
      await _persistLocal(uid, achievements);
    } catch (_) {
      // Sin conexión: seguimos con la copia local únicamente.
    }
    return achievements;
  }

  /// Desbloquea un logro si no lo estaba. Devuelve true si se acaba
  /// de desbloquear ahora mismo (para disparar la notificación).
  Future<bool> unlock(String? uid, Achievement achievement) async {
    if (achievement.unlocked) return false;
    achievement.unlocked = true;
    achievement.unlockedAt = DateTime.now();
    achievement.progress = 1.0;

    if (uid != null) {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_localKey(uid));
      final Map<String, dynamic> local = raw != null ? jsonDecode(raw) : {};
      local[achievement.id] = achievement.toMap();
      await prefs.setString(_localKey(uid), jsonEncode(local));

      try {
        await _firestore.upsertAchievementState(uid, achievement);
        await _firestore.addXp(uid, achievement.xp);
      } catch (_) {
        // Se sincronizará más adelante: queda guardado localmente.
      }
    }
    return true;
  }

  Future<void> _persistLocal(String uid, List<Achievement> achievements) async {
    final prefs = await SharedPreferences.getInstance();
    final map = {for (final a in achievements) a.id: a.toMap()};
    await prefs.setString(_localKey(uid), jsonEncode(map));
  }
}
