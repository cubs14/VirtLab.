import 'package:flutter/material.dart';
import '../models/experiment.dart';
import '../services/labi_service.dart';
import 'menu_screen.dart';

/// Chat real con Labi (Groq/Llama): burbujas de conversación con
/// historial e indicador de "escribiendo". Si viene de terminar un
/// experimento, arranca con retroalimentación sobre el puntaje; si se
/// abre libre desde el Menú, arranca con un saludo genérico. El
/// usuario puede seguir preguntando lo que quiera.
class LabiChatScreen extends StatefulWidget {
  final Experiment? experiment;
  final int? correctCount;
  final int? totalQuestions;

  const LabiChatScreen({
    super.key,
    this.experiment,
    this.correctCount,
    this.totalQuestions,
  });

  @override
  State<LabiChatScreen> createState() => _LabiChatScreenState();
}

class _LabiChatScreenState extends State<LabiChatScreen> {
  final _labi = LabiService();
  final _messages = <ChatTurn>[];
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _loadInitialFeedback();
  }

  Future<void> _loadInitialFeedback() async {
    if (widget.experiment == null) {
      // Chat abierto libremente desde el Menú: saludo genérico sin
      // gastar una llamada a la IA de más.
      setState(() {
        _messages.add(const ChatTurn(
          fromUser: false,
          text: '¡Hola! Soy LABI 🔬 tu compañero de aprendizaje en VirtLab. '
              'Pregúntame lo que quieras sobre ciencia, algún experimento, '
              'o pídeme una curiosidad.',
        ));
      });
      return;
    }
    setState(() => _sending = true);
    final reply = await _labi.getInitialFeedback(
      experimentTitle: widget.experiment!.title,
      correctCount: widget.correctCount ?? 0,
      totalQuestions: widget.totalQuestions ?? 0,
    );
    if (!mounted) return;
    setState(() {
      _messages.add(ChatTurn(fromUser: false, text: reply));
      _sending = false;
    });
    _scrollToEnd();
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() {
      _messages.add(ChatTurn(fromUser: true, text: text));
      _sending = true;
    });
    _inputCtrl.clear();
    _scrollToEnd();

    final reply = await _labi.sendMessage(_messages);
    if (!mounted) return;
    setState(() {
      _messages.add(ChatTurn(fromUser: false, text: reply));
      _sending = false;
    });
    _scrollToEnd();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset('assets/images/labi.jpg', width: 32, height: 32, fit: BoxFit.cover),
            ),
            const SizedBox(width: 10),
            const Text('Labi'),
          ],
        ),
        foregroundColor: Colors.white,
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MenuScreen()),
              (route) => false,
            ),
            child: const Text('Ir al menú', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollCtrl,
                padding: const EdgeInsets.all(16),
                itemCount: _messages.length + (_sending ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == _messages.length) {
                    return const _TypingBubble();
                  }
                  return _MessageBubble(turn: _messages[index]);
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _inputCtrl,
                        minLines: 1,
                        maxLines: 4,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _send(),
                        decoration: InputDecoration(
                          hintText: 'Pregúntale algo a Labi...',
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: _sending ? null : _send,
                      icon: const Icon(Icons.send),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final ChatTurn turn;
  const _MessageBubble({required this.turn});

  @override
  Widget build(BuildContext context) {
    final isUser = turn.fromUser;
    final primary = Theme.of(context).colorScheme.primary;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isUser ? primary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isUser ? 18 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 18),
          ),
        ),
        child: Text(
          turn.text,
          style: TextStyle(color: isUser ? Colors.white : Colors.black87, fontSize: 15),
        ),
      ),
    );
  }
}

class _TypingBubble extends StatelessWidget {
  const _TypingBubble();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
        child: const SizedBox(
          width: 24,
          height: 12,
          child: Center(child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))),
        ),
      ),
    );
  }
}
